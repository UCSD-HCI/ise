#!/bin/sh

cd "`dirname $0`"
clear


echo "Starting RefreshMyDesk..."
java -Xms512m -Xmx512m -cp ./bin:./lib/* edu.ucsd.hci.refresh.RefreshMyDeskHsqlDB
